<footer class="bg-blue-900 text-white text-center py-4">
    <p>Copyright &copy; <?php echo date('Y'); ?>. All Rights Reserved</p>
</footer>

</body>

</html>