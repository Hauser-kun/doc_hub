<?php
$conn= mysqli_connect("localhost","root","","ilovecode");

if(!$conn){
    die ("Connection fail".mysqli_connect_errno());
}

?>