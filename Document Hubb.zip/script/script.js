function signin(){
    window.location="/frontend/signin.php";
    // alert('hello')
}

function login(){
    window.location="/frontend/login.php";
}